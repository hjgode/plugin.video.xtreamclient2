import sys

config = {
    "url" : "http://sero-team.xyz",
    "port" : "8080",
    "username" : "HeinzJosefG",
    "password" : "HeinzJosefG891853",
    "filter"   : "DE",
    "filter_is_regex":   "false",
}
