# -*- coding: utf-8 -*-
#for python2
# Module: script.xtreamdownload
#         database_update.py
# version 0.0.1
# Author: HJ_G.
# Created on: 07.12.2021
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html

from __future__ import print_function

import os
import sys
import re
import datetime

try:
  import xbmc
  print ("No Testing, running with xbmc")
  #from xtutils import start_connection, get_settings, get_url
  from xtutils import *
except Exception as e:
  print ("Testing environent, running without xbmc")
  from xtutils_test import start_connection, get_settings

from simple_epg import Simple_Epg

from live_xtream_class import Live_Streams

class get_LiveArchive:
  def __init__(self):
    self.live_streams=None
    self._get_live_streams_instance()
    self.myclient=None
    self.simple_epg= Simple_Epg()
    self.mysettings=None
    self.myfilter=None
    self.myregex=None
    self._get_settings()
    pass # init

  def _get_settings(self):
    if self.mysettings==None:
      self.myclient=start_connection()
      self.mysettings=get_settings()
      self.myfilter=self.mysettings['filter']
      self.myregex=self.mysettings['filter_is_regex']

  def _get_live_streams_instance(self):
    if self.live_streams==None:
      self.live_streams=Live_Streams()
    return self.live_streams

  def _log(self, msg):
    if xbmc==None:
      print(msg)
    else:
      xbmc.log(msg, xbmc.LOGDEBUG)
    pass

  def get_timshift_url(self, stream_id, start, duration):
    myclient=self.myclient
    url = myclient.play_timeshift(stream_id, start, duration)
    #self._log("play_timeshift stream is: " + url)
    return url
    pass

  def get_simple_epg(self, channel_stream_id, channel_name):
    """ return simple epg """
    #simple_epg= Simple_Epg()
    epgdata = self.simple_epg.get_simple_epg(channel_stream_id)
    channel_info={}
    channel_info['channel_stream_id']=channel_stream_id
    channel_info['channel_name']=channel_name
    epg_infos=[]
    for epg in epgdata:
      if epg['has_archive']==1:
        epg_infos.append(epg)
    return epg_infos
    pass

  def get_channels_with_archive(self):
    """ return a list of channels that provide an archive 
        Returns:
          channel_name=channel['name']
          channel_stream_id=channel['stream_id']
    """
    live_streams=self._get_live_streams_instance()
    categories=live_streams.get_categories(self.myfilter, self.myregex)
    mylist=[]
    for c in categories:
      category_name=c['category_name']
      category_id=c['category_id']
      streams=live_streams.get_streams_by_category(category_id)
      self._log("searching thru "+category_name)
      if isinstance(streams,list):
        for channel in streams:
          if channel['tv_archive']==1:
            #we found a channel with archive
            #mylist.append(channel)
            channel_name=channel['name']
            channel_stream_id=channel['stream_id']
            mylist.append({'channel_name':channel_name, 'channel_stream_id':channel_stream_id})
    return mylist
    pass

  #TODO: ? get all infos at once (takes some time), or use a service or just
  # get channels with archive first and then epg when requested? 
  def get_archive_streams(self):
    live_streams=self._get_live_streams_instance()
    categories=live_streams.get_categories(self.myfilter, self.myregex)
    mylist=[]
    for c in categories:
      category_name=c['category_name']
      category_id=c['category_id']
      streams=live_streams.get_streams_by_category(category_id)
      self._log("searching thru "+category_name)
      if isinstance(streams,list):
        for channel in streams:
          if channel['tv_archive']==1:
            #we found a channel with archive
            #mylist.append(channel)
            channel_name=channel['name']
            channel_stream_id=channel['stream_id']
            """
            {u'category': 
            {u'category_id': u'83', u'category_name': u'DE \u2022 FullHD\u02b0\u1d49\u1d5b\u1d9c'}, 
            u'category_id': u'83', 
            u'epg_channel_id': u'DASERST', 
            u'name': u'Das Erste HD\u02b0\u1d49\u1d5b\u1d9c', 
            u'stream_id': 57221, 
            u'thumb': u'http://admin-serotv.com:8080/images/51e7682a87cfb0a577b3eb7123710739.png', 
            u'tv_archive': 1, 
            u'tv_archive_duration': 3, 
            u'video': u'http://sero-team.xyz:8080/play/v9OQ5ITy76wmBMEitt8VHiCyQUT5BLaKcmIAIf0V7CQXrdRjRhe2WvEcgGS3Iwrf/m3u8'
            }
            """
            #print(channel)
            simple_epg= Simple_Epg()
            epgdata = simple_epg.get_simple_epg(channel_stream_id)
            channel_info={}
            channel_info['channel_stream_id']=channel_stream_id
            channel_info['channel_name']=channel_name
            epg_infos=[]
            for epg in epgdata:
              if epg['has_archive']==1:
                epg_infos.append(epg)
#                mylist.append(epg_infos)
                """
                  Returns:
                  {u'lang': u'de', 
                  u'start_timestamp': 1641755701, 
                  u'end': u'2022-01-09 21:15:01', 
                  u'description': 'Die Sendereihe zeigt eine Zusammenfassung aller Spiele und Tore des aktuellen Spieltags.', 
                  u'start': u'2022-01-09 20:15:01', 
                  u'now_playing': 0, 
                  u'title': 'Admiral BL: Alle Spiele, alle Tore', 
                  u'epg_id': u'22', 
                  u'channel_id': u'skysportaustria.at_1', 
                  u'has_archive': 1, 
                  u'id': 1641755700, 
                  u'stop_timestamp': 1641759301}

                  {u'lang': u'de', 
                  u'start_timestamp': 1641716101, 
                  u'end': u'2022-01-09 10:15:01', 
                  u'description': 'Die Sendereihe zeigt eine Zusammenfassung aller Spiele und Tore des aktuellen Spieltags.', 
                  u'start': u'2022-01-09 09:15:01', 
                  u'now_playing': 0, 
                  u'title': 'Admiral BL: Alle Spiele, alle Tore', 
                  u'epg_id': u'22', 
                  u'channel_id': u'skysportaustria.at_1', 
                  u'has_archive': 1, 
                  u'id': 1641716100, 
                  u'stop_timestamp': 1641719701}
                """
            # get epg for tv_archive_duration?
            channel_info['simple_epg']=epg_infos
            mylist.append(channel_info)
            channel_info={}
            epg_infos=[]
        #end has_archive
    return mylist
    pass # get archive streams

  pass # class

#### TEST
get_archive = get_LiveArchive()
get_archive.get_timshift_url(57259, '2022-01-08 02:15:01', 120)

liste=get_archive.get_channels_with_archive()
for e in liste:
  print(e)
  # ie
  """
  {'channel_name': u'ServusTV \xd6sterreich HD', 'channel_stream_id': 78778}
  {'channel_name': u'Sky 1 HD \u2022 HEVC', 'channel_stream_id': 57259}
  ...
  {'channel_name': u'Sky Sport Bundesliga 4 HEVC', 'channel_stream_id': 40596}
  {'channel_name': u'Eurosport 1 HEVC', 'channel_stream_id': 40602}
  {'channel_name': u'Eurosport 2 HEVC', 'channel_stream_id': 40603}
  {'channel_name': u'Sky Sport Austria 1 HEVC', 'channel_stream_id': 40612}
  """

epg_list=get_archive.get_simple_epg(57259, u'Sky 1 HD \u2022 HEVC')
for e in epg_list:
  print (e)
  #ie
  """
  {u'lang': u'de', 
    u'start_timestamp': 1641601801, 
    u'end': u'2022-01-08 02:15:01', 
    u'description': '\xe2\x80\x9eDer Parkplatzw\xc3\xa4chter\xe2\x80\x9c Neil (Joe Egender) ist der einzige Zeuge in einem Mordfall \xe2\x80\x93 und Autist. Um den Fall zu l\xc3\xb6sen, ist Steve (Alex O\xe2\x80\x99Loughlin) aber auf die Hilfe des verschlossenen Mannes bei den Ermittlungen angewiesen. Kein leichter Job\xe2\x80\xa6.', 
    u'start': u'2022-01-08 01:30:01', 
    u'now_playing': 0, 
    u'title': 'Hawaii Five-0', 
    u'epg_id': u'20', 
    u'channel_id': u'sky1.de_1', 
    u'has_archive': 1, 
    u'id': 1641601800, 
    u'stop_timestamp': 1641604501}
  {u'lang': u'de', 
    u'start_timestamp': 1641604501, 
    u'end': u'2022-01-08 02:55:01', 
    u'description': 'Das Team erwartet diesmal \xe2\x80\x9eEine haarige Angelegenheit\xe2\x80\x9c: Steves alter Freund und Friseur Odell (Michael Imperioli) soll den Informanten Sang Min aus einer Mordanklage rausboxen.', 
    u'start': u'2022-01-08 02:15:01', 
    u'now_playing': 0, 
    u'title': 'Hawaii Five-0', 
    u'epg_id': u'20', 
    u'channel_id': u'sky1.de_1', 
    u'has_archive': 1, 
    u'id': 1641604500, 
    u'stop_timestamp': 1641606901}
    """
duration=datetime.timedelta(1641606901-1641604501)
print(duration)

get_archive.play_archive(57259, '2022-01-08 02:15:01', 120)