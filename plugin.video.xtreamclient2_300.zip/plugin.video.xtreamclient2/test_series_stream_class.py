# coding=utf-8
import __future__
# test live_xstreams class

from series_stream_class import Series_Streams

series_streams=Series_Streams()

# get all known series categories
categories=[]
categories=series_streams.get_categories('DE ', 'false')
if isinstance(categories, list):
  for c in categories:
    print(c['category_name'] + ' : ' + c['category_id'])
else:
  print(type(categories))

#get all series inside category
series=series_streams.get_Series_by_category('121')
if series:
  for s in series:
    print(s['name'] + ':' + str(s['series_id']))

#get seasons of serie
seasons=series_streams.list_seasons_in_serie('915') #915 = smallville
if seasons:
  for s in seasons:
    print(s['season'] + ' : ' + s['title'] + ' : ' + s['set'])

#get episodes for season
episodes=series_streams.list_episodes_in_season('1', '915')
if episodes:
  for e in episodes:
    print(e['title']+' : ' + e['video'])