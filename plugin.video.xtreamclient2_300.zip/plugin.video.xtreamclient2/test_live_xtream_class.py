# coding=utf-8
import __future__
# test live_xstreams class

from live_xtream_class import Live_Streams

live_streams=Live_Streams()

categories=[]
categories=live_streams.get_categories('DE ', 'false')
if isinstance(categories, list):
  for c in categories:
    print(c['category_name'] + ' : ' + c['category_id'])
else:
  print(type(categories))

id=live_streams._get_category_id(u'DE • RawHD⁵⁰ᶠᵖˢ')

streams=live_streams.get_streams_by_category(id)
for s in streams:
  print(s['name'])