# # -*- coding: utf-8 -*-
#for python2
# Module: script.xtreamdownload
# version 0.0.1
# Author: HJ_G.
# Created on: 07.12.2021
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html

import sys
import os
import socket
import urllib
from urlparse import parse_qsl

import xbmc
import xbmcgui
import xbmcaddon

# create a class for your addon, we need this to get info about your addon
ADDON = xbmcaddon.Addon()
# get the full path to your addon, decode it to unicode to handle special (non-ascii) characters in the path
CWD = ADDON.getAddonInfo('path')

# add a class to create your xml based window
class GUI(xbmcgui.WindowXML):
    # [optional] this function is only needed of you are passing optional data to your window
    def __init__(self, *args, **kwargs):
        # get the optional data and add it to a variable you can use elsewhere in your script
        self.data = kwargs['optional1']

    # until now we have a blank window, the onInit function will parse your xml file
    def onInit(self):
        # select a view mode, '50' in our case, as defined in the skin file
        xbmc.executebuiltin('Container.SetViewMode(50)')
        # define a temporary list where we are going to add all the listitems to
        listitems = []
        # this will be the first item in the list. 'my first item' will be the label that is shown in the list
        listitem1 = xbmcgui.ListItem('my first item')
        # add this item to our temporary list
        listitems.append(listitem1)
        # let's create another item
        listitem2 = xbmcgui.ListItem('my second item')
        # and add it to the temporary list as well
        listitems.append(listitem2)
        # by default the built-in container already contains one item, the 'up' (..) item, let's remove that one
        self.clearList()
        # now we are going to add all the items we have defined to the (built-in) container
        self.addItems(listitems)
        # give kodi a bit of (processing) time to add all items to the container
        xbmc.sleep(100)
        # this puts the focus on the top item of the container
        self.setFocusId(self.getCurrentContainerId())

def log(s):
  xbmc.log(s, xbmc.LOGNOTICE)

if __name__ == '__main__' :
    log(ADDON.getAddonInfo('id'))
    args=sys.argv
    #sys.argv[0] is name of xbmc script
    for a in args:
      log(a) # name=... and stream=...
    """2021-12-29 10:34:00.939 T:140079631361792  NOTICE: script.xtreamdownload
      2021-12-29 10:34:00.939 T:140079631361792  NOTICE: default.py
      2021-12-29 10:34:00.939 T:140079631361792  NOTICE: ?name=96%20Hours%20%282008%29...
    """
    if len(sys.argv)!=2:
      quit()
    #sys.argv[1] is name of python file
    log('sys.argv[1] is: ' + sys.argv[1])
    #parse_qsl will also uncode html entyities
    params = dict(parse_qsl(sys.argv[1][1:]))
    for p in params:
      log(p + "=" + params[p])
    
    #FIXME
    SOCKET = os.path.join(CWD,'lockfile')# '/var/run/service.xtreamclient2.sock'
    sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    sock.connect(SOCKET)
    sock.send( ('start='+ sys.argv[1][1:]).encode('utf-8'))
    sock.close()

    # media windows only have one builtin list and we need two, therefor we're not using the built-in container, so do not set the fifth argument (it defaults to False)
    # define your xml window and pass these five arguments (more optional items can be passed as well):
    # 1 'the name of the xml file for this window', 
    # 2 'the path to your addon',
    # 3 'the name of the folder that contains the skin',
    # 4 'the name of the folder that contains the skin xml files'
    # 5 set to True for a media window (a window that will list music / videos / pictures), set to False otherwise
    # 6 [optional] if you need to pass additional data to your window, simply add them to the list
    # you'll have to add them as key=value pairs: key1=value1, key2=value2, etc...
#    ui = GUI('script-testwindow.xml', CWD, 'default', '1080i', True, optional1='some data')
    # now open your window. the window will be shown until you close your addon
#    ui.doModal()
    # window closed, now cleanup a bit: delete your window before the script fully exits
#    del ui
