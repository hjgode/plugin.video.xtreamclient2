# coding=utf-8
# live xtream API
# Module: live_xtream
# Author: HJ_G.
# Created on: 09.12.2021
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html

#for utf-8 and python3 compatibility
from __future__ import unicode_literals
from __future__ import print_function
import sys

# sys.setdefaultencoding('utf8')
import os

from CountdownDialog import CountdownDialog
from client import Client

import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon

# create a class for your addon, we need this to get info about your addon
ADDON = xbmcaddon.Addon()
# get the full path to your addon, decode it to unicode to handle special (non-ascii) characters in the path
CWD = ADDON.getAddonInfo('path') #.decode('utf-8')
sys.path.append(CWD)

def log(msg, level=xbmc.LOGINFO):
    plugin = "plugin.video.xtreamclient"
    xbmc.log("[%s] %s" % (plugin, msg.__str__()), level)
    
log(CWD)

log(sys.version_info)

lock=None
def show_dialog(msg):
    dialog = xbmcgui.Dialog()
    dlg=CountdownDialog(ADDON.getAddonInfo('name'),msg, '', '', True, 15, 3)
    
    ok = dialog.ok(ADDON.getAddonInfo('name'), msg)

# Get the plugin url in plugin:// notation.
_URL = sys.argv[0]
# Get the plugin handle as an integer number.
_HANDLE = int(sys.argv[1])

myconfig={} # cfg.config
def get_settings():
    log("get_settings...")
    global myconfig
    myconfig={}
    my_addon = xbmcaddon.Addon()
    #     url = cfg.config["url"] + ":" + cfg.config["port"] + "?username=" + cfg.config["username"] + "&password=" + cfg.config["password"]
    myconfig['url']=my_addon.getSetting('sett_website')
    myconfig['username']=my_addon.getSetting('sett_username')
    myconfig['password']=my_addon.getSetting('sett_password')
    myconfig['port']=my_addon.getSetting('sett_portnumber')
    myconfig['filter']=my_addon.getSetting('sett_filter')
    myconfig['filter_is_regex']=my_addon.getSetting('sett_filter_is_regex') # returns the string 'true' or 'false'
    my_addon.setSetting('my_setting', 'false')
    return myconfig

#from categories_class import Categories

myclient=None
def start_connection():
    myconfig=get_settings()
    url = myconfig["url"] + ":" + myconfig["port"] + "?username=" + myconfig["username"] + "&password=" + myconfig["password"]
    client=Client(url)
    #print(client)
    return client
