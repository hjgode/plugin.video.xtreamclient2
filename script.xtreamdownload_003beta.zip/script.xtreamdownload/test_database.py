# -*- coding: utf-8 -*-
#for python2
# Module: script.xtreamdownload
#         service.py
# version 0.0.1
# Author: HJ_G.
# Created on: 07.12.2021
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html

from database import Database
import os
directory_path = os.getcwd()

print('##################')
print(directory_path)

database=Database(directory_path)

id = database.add_item("title1", "http://sero-team.xyz:8080/play/28gXuXPqitBI-xnTnLR1tcLpvHBn2ODI4_Fkc773OU1BuOa_vAS0TUICHWvCEujd")
print("inserted with id="+str(id))
database.remove_item('http://sero-team.xyz:8080/play/28gXuXPqitBI-xnTnLR1tcLpvHBn2ODI4_Fkc773OU1BuOa_vAS0TUICHWvCEujd')
id = database.add_item("title2", "stream2")
print("inserted with id="+str(id))
id = database.add_item("title3", "stream1") #deletes title1 row, as stream is unique!
print("inserted with id="+str(id))

database.list_items()

database._close_db()