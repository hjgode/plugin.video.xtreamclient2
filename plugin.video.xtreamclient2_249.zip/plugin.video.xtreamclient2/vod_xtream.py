# # -*- coding: utf-8 -*-
# vod xtream API
# Module: vod_xtream
# Author: HJ_G.
# Created on: 09.12.2021
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html

#for utf-8 and python3 compatibility
from __future__ import unicode_literals
from __future__ import print_function
import sys
import re

#from xtutils import start_connection, get_settings, get_url
from xtutils import *

from client import Client

import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon

#TODO: remove for release
#import web_pdb
#TODO: remove for release
#web_pdb.set_trace()

import re

# create a class for your addon, we need this to get info about your addon
ADDON = xbmcaddon.Addon()
# get the full path to your addon, decode it to unicode to handle special (non-ascii) characters in the path
CWD = ADDON.getAddonInfo('path') #.decode('utf-8')
sys.path.append(CWD)
# Get the plugin handle as an integer number.
_HANDLE = int(sys.argv[1])

from xtutils import *
from xtutils import start_connection
from categories_class import Categories

myclient=None
def get_Vod_categories():
    global myclient
    myclient=start_connection()
    categories=myclient.vod_categories()
    if categories==None:
        error=myclient.get_last_error()
        show_dialog("ERROR (getting VOD cats): "+error)
    return categories


def get_vod_by_category(category):
    """ return a list of Categories_class objects for videos """
    myclient=start_connection()
    videos=myclient.vod_streams_by_category(category)  
    if videos==None:
        error=myclient.get_last_error()
        show_dialog("ERROR (4): "+error)
  
    mylist=[]
    if isinstance (videos, list):        
        for o in videos :
            #TODO: fixme Mapping
            item={}
            item['name']=o['name']
            item['video']=o['direct_source']
            item['thumb']=o['stream_icon']
            item['category']=category
            item['category_id']=o['category_id']
            item['year']=o['year']
            item['thumb']=o['stream_icon']
            item['plot']=o['plot']
            item['genre']=o['genre']
            item['title']=o['title']
            mylist.append(item)
            #mylist[o['name']]=item
            #categories[o['category_name']]={}
            #categories[o['category_name']]['category_name']=o['category_name']
            #categories[o['category_name']]['category_id']=o['category_id']
            #cats.add(o['category_name'], o['category_id'])
                
    return mylist

def get_vod_videos(category):
    vids=get_vod_by_category(category)
    log("### list video for category="+category)
    return vids #VIDEOS.get_id(category)

VOD = get_Vod_categories()

def list_vod_categories():
    global VOD
    global myconfig
    myconfig=get_settings()
    """
    Create the list of video categories in the Kodi interface.
    """
    # Set plugin category. It is displayed in some skins as the name
    # of the current section.
    xbmcplugin.setPluginCategory(_HANDLE, 'VideoOnDemand Collection')
    # Set plugin content. It allows Kodi to select appropriate views
    # for this type of content.
    xbmcplugin.setContent(_HANDLE, 'videos')
    # Get video categories
    categories = get_Vod_categories()
    # Iterate through categories
    log("###list_vod_categories: "+str(categories))
    vods=Categories()
    filterstr=myconfig['filter']
    filterregex=myconfig['filter_is_regex']
    p=None
    if filterregex=='true':
        try:
            p=re.compile(filterstr);
        except Exception:
            log("ERROR with regex: "+filterstr)
            p=None
    if p==None:
        filterregex='false'    
    for category in categories:
        if len(filterstr)>0:
            if filterregex=="true":
                if re.match(p, category['category_name'])==None:
                    continue
            elif not category['category_name'].startswith(filterstr):
                continue
        #Need a global?
        vods.add(category['category_name'], category['category_id'])
        # Create a list item with a text label and a thumbnail image.
        list_item = xbmcgui.ListItem(label=category['category_name'])
        # Set graphics (thumbnail, fanart, banner, poster, landscape etc.) for the list item.
        # Here we use the same image for all items for simplicity's sake.
        # In a real-life plugin you need to set each image accordingly.
        #list_item.setArt({'thumb': VIDEOS.get_categories()[category][0]['thumb'],
        #                  'icon': VIDEOS.get_categories()[category][0]['stream_icon'],
        #                  'fanart': VIDEOS.get_categories()[category][0]['thumb']})
        
        # Set additional info for the list item.
        # Here we use a category name for both properties for for simplicity's sake.
        # setInfo allows to set various information for an item.
        # For available properties see the following link:
        # https://codedocs.xyz/xbmc/xbmc/group__python__xbmcgui__listitem.html#ga0b71166869bda87ad744942888fb5f14
        # 'mediatype' is needed for a skin to display info for this ListItem correctly.
        list_item.setInfo('video', {'title': category['category_name'],
                                    'set': category['category_id'],
                                    'mediatype': 'video'})
        # Create a URL for a plugin recursive call.
        # Example: plugin://plugin.video.example/?action=listing&category=Animals
        url = get_url(action='list_vod_for_cat', category_id=category['category_id'], category_name=category['category_name'])
        # is_folder = True means that this item opens a sub-list of lower level items.
        is_folder = True
        # Add our item to the Kodi virtual folder listing.
        xbmcplugin.addDirectoryItem(_HANDLE, url, list_item, is_folder)
    #global
    VOD=vods
    # Add a sort method for the virtual folder items (alphabetically, ignore articles)
    xbmcplugin.addSortMethod(_HANDLE, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
    # Finish creating a virtual folder.
    xbmcplugin.endOfDirectory(_HANDLE)

def list_vod_streams(category_id, category_name):
    """
    Create the list of playable videos in the Kodi interface.

    :param category: Category name
    :type category: str
    """
    global VOD
    # Set plugin category. It is displayed in some skins as the name
    # of the current section.
    xbmcplugin.setPluginCategory(_HANDLE, category_name)
    # Set plugin content. It allows Kodi to select appropriate views
    # for this type of content.
    xbmcplugin.setContent(_HANDLE, 'videos')
    # Get the list of videos in the category.
    #FIXME: need another global for VODs
    id=category_id
    #TODO: FIXME, keyError as dict is looked by a non-utf8 string
    videos = get_vod_videos(id) # get_videos(category)
    log("list_vod_streams...")
    # Iterate through videos.
    for video in videos:
        log("list_vod_streams, list_item=video: "+str(video))
        # Create a list item with a text label and a thumbnail image.
        list_item = xbmcgui.ListItem(label=video['name'])
        # Set additional info for the list item.
        # 'mediatype' is needed for skin to display info for this ListItem correctly.
        id=video['category_id']
        genre=''#VOD.get_name(id) #change for VOD
        list_item.setInfo('video', {'title': video['name'],
                                    'set': genre, #video['category'],
                                    'year':video['year'],
                                    'mediatype': 'video',
                                    "plot" : video["plot"]})
        # Set graphics (thumbnail, fanart, banner, poster, landscape etc.) for the list item.
        # Here we use the same image for all items for simplicity's sake.
        # In a real-life plugin you need to set each image accordingly.
        list_item.setArt({'thumb': video['thumb'], 'icon': video['thumb'], 'fanart': video['thumb']})
        # Set 'IsPlayable' property to 'true'.
        # This is mandatory for playable items!
        list_item.setProperty('IsPlayable', 'true')
        # Create a URL for a plugin recursive call.
        # Example: plugin://plugin.video.example/?action=play&video=http://www.vidsplay.com/wp-content/uploads/2017/04/crab.mp4
        url = get_url(action='play', video=video['video'])
        # Add the list item to a virtual Kodi folder.
        # is_folder = False means that this item won't open any sub-list.
        is_folder = False
        # Add our item to the Kodi virtual folder listing.
        xbmcplugin.addDirectoryItem(_HANDLE, url, list_item, is_folder)
    # Add a sort method for the virtual folder items (alphabetically, ignore articles)
    xbmcplugin.addSortMethod(_HANDLE, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
    # Finish creating a virtual folder.
    xbmcplugin.endOfDirectory(_HANDLE)
