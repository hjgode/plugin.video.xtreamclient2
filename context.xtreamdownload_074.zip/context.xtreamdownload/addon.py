# -*- coding: utf-8 -*-
import os
import xbmc
import xbmcaddon
import xbmcgui
import time
import re

import urllib2

addon = xbmcaddon.Addon()    
folder = addon.getSetting("folder")

def _mydecodeHTML(url):
  s=url.replace("http%3A%2F%2F", "http://")
  s=s.replace("%2F","/")
  s=s.replace("%3A",":")
  return s

def getplayurl(splaypath):
  """  test_path_string=
        "plugin://plugin.video.xtreamclient2/?action=play&video=http%3A%2F%2Fsever.xyz%3A8080%2Fplay%2FYG7lSWcYcEph46xPtEwsJ6n5A8pyB-FN6dXxQMOmKcIYdZrTDrbaXSDnHVf9RLgs" 
      return: 
        http://server.xyz:8080/play/YG7lSWcYcEph46xPtEwsJ6n5A8pyB-FN6dXxQMOmKcIYdZrTDrbaXSDnHVf9RLgs
  """
  myurl=None
  match=re.match(r".*=play&video=(?P<url>.*)", splaypath)
  if match:
    myurl=match.group('url')
    myurl=_mydecodeHTML(myurl)
  return myurl

def debug(content):
  log(content, xbmc.LOGDEBUG)
    
def notice(content):
  log("#######" + content, xbmc.LOGNOTICE)

def log(msg, level=xbmc.LOGNOTICE):
  addon = xbmcaddon.Addon()
  addonID = addon.getAddonInfo('id')
  xbmc.log('%s: %s' % (addonID, msg), level) 

def replaceuglychars(filename):
  uglyfilechars=r'[\[\]\'\{\},;:+"\\/:"*?<>\|]+'
  newstr=re.sub(uglyfilechars, "_", filename)
  return newstr

def httpdownload(url, file_name):
  USERAGENT = "Mozilla/5.0 (Windows; U; Windows NT 6.1; en-GB; rv:1.9.2.8) Gecko/20100722 Firefox/3.6.8"

  file_name=replaceuglychars(file_name)
  
  if not file_name.endswith(".mkv"):
    file_name=file_name+".mkv"
  outpath = os.path.join(folder, file_name)   
  dialog = xbmcgui.Dialog()
  ret = dialog.yesno('Xtream download', "Start download of {} to {}?".format(url, outpath))
  if not ret:
    return

  if os.path.exists(outpath):
    ret=dialog.yesno("Xtream download", "File {} already exists. Overwrite?".format(file_name))
    if not ret:
      return
        
  url = urllib2.Request(url)
  url.add_header("User-Agent", USERAGENT)  

  u = urllib2.urlopen(url)
  
  f = open(outpath, 'wb')
  meta = u.info()
  file_size = int(meta.getheaders("Content-Length")[0])
  print ("Downloading: %s Bytes: %s" % (outpath, file_size))

  file_size_dl = 0
  block_sz = 1024*1024*10 # 10MB
  dlg=xbmcgui.DialogProgress()
  dlg.create("Xtream download", "Downloading "+str(file_size)+" bytes", "File: "+outpath)
  aborted=False
  try:
    while True:
      start = time.time()
      buffer = u.read(block_sz)
      end = time.time()
      if not buffer:
          dlg.update(percent=100,line3="Done")            
          break
      time_difference = end - start
      speed=round(len(buffer)/time_difference/1000)
      file_size_dl += len(buffer)
      f.write(buffer)
      f.flush()
      percent_done=int(file_size_dl * 100. / file_size)
      status = r"%10d  [%3.2f%%] " % (file_size_dl, percent_done) + "("+str(speed)+")"
      status = status + chr(8)*(len(status)+1)
      sspeed="%5i%%    %5.2f" % (percent_done, speed)
      dlg.update(percent=percent_done, line3=sspeed)
      if dlg.iscanceled():
        dlg.close()
        if dialog.yesno("Xtream download", "Delete partial file {}?".format(outpath)):
          os.remove(outpath)
        break
  except urllib2.HTTPError as e:
      notice ("HTTP Error: " + e.code +", " + url)
      aborted=True
  except urllib2.URLError as e:
      notice ("URL Error: " + e.reason +", " + url)
      aborted=True
  if aborted:
      dlg.update(line3="Download failed")
      
  if dlg!=None:
    time.sleep(3)
    dlg.close()
  f.close()

#MAIN    

#xbmcgui.ListItem
path = sys.listitem.getPath()
title = sys.listitem.getLabel()
notice('clicked on: '+ title+ ' / ' + path)
"""
2021-12-26 08:58:07.185 T:1436541824  NOTICE: context.downloadit: clicked on: Sh
in Godzilla (2016), plugin://plugin.video.xtreamclient2/?action=play&video=http%
3A%2F%2Fserver.xyz%3A8080%2Fplay%2FYG7lSWcYcEph46xPtEwsJ6n5A8pyB-FN6dXxQMOmKc
IYdZrTDrbaXSDnHVf9RLgs
"""
notice(repr(title))

# start video
kodi_player = xbmc.Player()
kodi_player.play(path, sys.listitem)
time.sleep(10) 
videoda=0

# until the first file is played read file
while videoda==0 :
    try:
        file=kodi_player.getPlayingFile()
        debug("-----> "+file)
        if not file=="":
            videoda=1
    except:
        pass 

kodi_player.stop()
notice("KodiPlayer playing file: "+file)
"""
2021-12-27 15:00:26.356 T:140394876626688  NOTICE: context.xtreamdownload: '96 H
ours - Taken 3 (2014)'
2021-12-27 15:00:27.363 T:140395496819904  NOTICE: VideoPlayer::OpenFile: plugin
://plugin.video.xtreamclient2/?action=play&video=http%3A%2F%2Fserver.xyz%3A80
80%2Fplay%2FYG7lSWcYcEph46xPtEwsJ6n5A8pyB-FN6dXxQMOmKcK_1i92hcSaTijV2nl2xPh7
"""
url=file
notice("downloadfile: "+url+", "+ title)
newurl=_mydecodeHTML(url)
notice("newurl= " + newurl)
httpdownload(newurl,title)
