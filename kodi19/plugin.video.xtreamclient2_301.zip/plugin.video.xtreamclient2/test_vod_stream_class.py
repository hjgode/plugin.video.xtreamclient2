# coding=utf-8
import __future__
# test live_xstreams class

from vod_stream_class import Vod_Streams

vod_streams=Vod_Streams()

categories=[]
categories=vod_streams.get_categories('DE ', 'false')
if isinstance(categories, list):
  for c in categories:
    print(c['category_name'] + ' : ' + c['category_id'])
else:
  print(type(categories))

streams=vod_streams.get_streams_by_category('762')
for s in streams:
  print(s['video'])
