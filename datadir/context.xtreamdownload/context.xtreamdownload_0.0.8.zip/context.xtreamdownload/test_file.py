# -*- coding: utf-8 -*-
#for python2/3
# Module: context.xtreamdownload
#         addon.py
# version 0.0.8
# Author: HJ_G.
# Created on: 07.12.2021
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html

import os
import io
import sys


#/home/hgode/Videos/Autopsie - Mysteriöse Todesfälle - S01E01 - Die Bestie von Oak Cliff u.a..mkv
outpath="/home/hgode/Videos/Autopsie - Mysteri\xc3\xb6se Todesf\xc3\xa4lle - S01E01 - Die Bestie von Oak Cliff u.a..mkv"
#"/home/hgode/Videos/Autopsie - Mysteriöse Todesfälle - S01E01 - Die Bestie von Oak Cliff u.a..mkv"

enc=sys.getfilesystemencoding()

s=str(outpath,'utf-8')
print("filesystem encoding=" + enc)
utfb=str.encode(outpath) #, 'utf-8')
utfb2=bytes(outpath,"utf8")
utfs=utfb.decode('utf-8')

print (str(utfb))
"""
print("outpath: " + outpath)
print("str(): " + str(utfb))
print("utfs: " + utfs)
print("utfb: " + str(utfb))
print("utfb2: " + str(utfb2))

file=io.open(str(utfb,'utf-8'), "wb")
file.close()
"""